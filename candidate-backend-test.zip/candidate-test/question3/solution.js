function findTheLowerCaseWOrd(str) {
  
}

module.exports = findTheLowerCaseWOrd;