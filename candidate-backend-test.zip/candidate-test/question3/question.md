find the hidden lowercase word inside uppercase characters

*   The wanted word is in **lowercase**.
*   The garbage letters are all in **uppercase**.
*   please note **remain lowercase should be in the same order**.

### Examples

    findTheLowerCaseWOrd("UdUNTFYGoFYFYGBVtNUXHUYTYM") ➞ "dot"
    
    findTheLowerCaseWOrd("bETYEPOFGBuFOIUBRrHgUHlNFYaYYYr") ➞ "burglar"
    
    findTheLowerCaseWOrd("YFbmHSEUFBbezFBYzFBYLleGBYEFGBMENTmenz") ➞ "bmbezzlemenz"

### Notes

N/A