Move all uppercase letters to the first

### Examples

    moveAllUppercaseLetetrsToFirst("hOpPy") ➞ "OPhpy"
    
    moveAllUppercaseLetetrsToFirst("moveIT") ➞ "ITmove"
    
    moveAllUppercaseLetetrsToFirst("shOrtKUT") ➞ "OKUTshrt"

### Notes

you answer should keep the original relative orders of the capital and non-capital letters as it is.