function moveAllUppercaseLetetrsToFirst(s) {

}

module.exports = moveAllUppercaseLetetrsToFirst;