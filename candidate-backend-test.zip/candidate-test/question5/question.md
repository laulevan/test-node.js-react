Write a function that converts an object into an array of keys and values.

### Examples

    convertToArray({
      D: 1,
      B: 2,
      C: 3
    }) ➞ [["D", 1], ["B", 2], ["C", 3]]
    
    convertToArray({
      attA: 2,
      attB: 3,
      attC: 10
    }) ➞ [["attA", 2], ["attB", 3], ["attC", 10]]

### Notes

N/A