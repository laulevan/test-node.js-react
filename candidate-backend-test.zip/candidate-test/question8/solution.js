function howManyDaysBetweenTwoDates(date1, date2) {
	
}

module.exports = howManyDaysBetweenTwoDates;