Calculate the number of days between two dates.

### Examples

    howManyDaysBetweenTwoDates(
      new Date("June 14, 2020"),
      new Date("June 20, 2020")
    ) ➞ 6
    
    howManyDaysBetweenTwoDates(
      new Date("December 29, 1900"),
      new Date("January 1, 1900")
    ) ➞ 3
    
    howManyDaysBetweenTwoDates(
      new Date("July 20, 2020"),
      new Date("July 30, 2020")
    ) ➞ 10

### Notes

N/A