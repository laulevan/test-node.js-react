function canGetNestedInside(arr1, arr2) {
	
}

module.exports = canGetNestedInside;