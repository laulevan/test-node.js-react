Write a function that checks whether a number is **sumOfAllDigitsIsOdd** or **sumOfAllDigitsIsEven**.

For example, `sumOfAllDigitsIsOddOrsumOfAllDigitsIsEven(125)` should return `"sumOfAllDigitsIsEven"`, since 1 + 2 + 5 = 8. `sumOfAllDigitsIsOddOrsumOfAllDigitsIsEven(49)` should return `"sumOfAllDigitsIsOdd"`, since 4 + 9 = 13.

### Examples

    sumOfAllDigitsIsOddOrsumOfAllDigitsIsEven(43) ➞ "sumOfAllDigitsIsOdd"
    
    sumOfAllDigitsIsOddOrsumOfAllDigitsIsEven(373) ➞ "sumOfAllDigitsIsOdd"
    
    sumOfAllDigitsIsOddOrsumOfAllDigitsIsEven(4433) ➞ "sumOfAllDigitsIsEven"

### Notes

N/A