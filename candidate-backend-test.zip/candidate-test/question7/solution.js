function sumOfAllDigitsIsOddOrsumOfAllDigitsIsEven(num) {
	
}

module.exports = sumOfAllDigitsIsOddOrsumOfAllDigitsIsEven;