module.exports = {
  roots: [
    '<rootDir>',
  ],
  testEnvironment: 'node',
  testMatch: ['**/?(*.)+(spec|test).js']
}