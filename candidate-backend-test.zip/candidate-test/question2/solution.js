function insertArrayInTheMiddle(arr1, arr2) {
	
}

module.exports = insertArrayInTheMiddle;