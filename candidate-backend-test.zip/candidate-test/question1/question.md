This question is just a sample to get you familiar with test structure
Just write a simple function to return sum of two given numbers.

### Examples

    sum(1, 2) ➞ 3

    sum(0, 0) ➞ 0

    sum(-1, 1) ➞ 0
  
### Notes

N/A