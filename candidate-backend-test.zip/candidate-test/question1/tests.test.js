const sum = require('./solution');

describe('sum', () => {
  test('test 1', () => {
    expect(sum(1, 2)).toBe(3);
  });
});


