function getNumberOfLayers(rug) {
  
}

module.exports = getNumberOfLayers;