# Machine Ventures Front-end web development Code Challenge

# Task
We need you to implement MyKuya’s pages like home and map:
  - Design: Please implement all designs of the screen folder of the zip file. We've also shared a screen recording for you to better understand the User Experience
  - API: Create API call with mock data
  - Test: The code must have acceptable test coverage
  
# Technology
Please create this project using react.js

# Resources
You can find the requested pages' screenshots in the zip folder we've sent you with this challenge.
Please note that you must implement all pages requested.

# Submission
When you finished the task, please commit your codes in a git repository and share it with us.

